    </div>
  </div>
</div>

<!--body-cont-end-->
<div id="fot">
<footer> 
  
  <!--1-->
  <div class="container">
    <div class="row">
      <div class="col-lg-3a col-md-3a col-sm-3a footertop">
        <h2>Company</h2>
        <ul>
          <li><a href="#">About Us</a></li>
          <li><a href="#">Careers</a></li>
          <li><a href="#">Sitemap</a></li>
        </ul>
      </div>
      <div class="col-lg-3a col-md-3a col-sm-3a footertop">
        <h2>Need Help?</h2>
        <ul>
          <li><a href="#">FAQ</a></li>
          <li><a href="#">24x7 Customer Care</a></li>
          <li><a href="#">Contact Us</a></li>
        </ul>
      </div>
      <div class="col-lg-3a col-md-3a col-sm-3a footertop">
        <h2>Mobile</h2>
        <ul>
          <li><a href="#">Nokia</a></li>
          <li><a href="#">Google Nexus</a></li>
          <li><a href="#">Samsung</a></li>
        </ul>
      </div>
      <div class="col-lg-3a col-md-3a col-sm-3a footertop">
        <h2>Tablets</h2>
        <ul>
          <li><a href="#">Lava</a></li>
          <li><a href="#">Karbon</a></li>
          <li><a href="#">Lenovo</a></li>
        </ul>
      </div>
      <div class="col-lg-3a col-md-3a col-sm-3a footertop">
        <h2>Laptop</h2>
        <ul>
          <li><a href="#">Dell</a></li>
          <li><a href="#">Lenovo</a></li>
          <li><a href="#">Acer</a></li>
        </ul>
      </div>
    </div>
  </div>
  
  <!--2-->
  <div class="container">
    <div class="row">
      <div class="col-lg-8 col-md-8 col-sm-8 col-md-push-2 footerlocation">
        <div class="col-lg-4 col-md-4 col-sm-4 ">
          <div class="footerlocationinD">
            <div class=" pull-left" style="width: 52px;"><img src="<?php echo $this->config->item('base_url');?>assets/front/images/ft-location.png" alt=""></div>
            <div class="footerlocationin">Track Your <br/>
              Order</div>
          </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-4 ">
          <div class="footerlocationinD">
            <div class=" pull-left" style="width: 52px;"><img src="<?php echo $this->config->item('base_url');?>assets/front/images/ft-refresh.png" alt="" ></div>
            <div class="footerlocationin">Free &amp; Easy <br/>
              Returns</div>
          </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-4 ">
          <div class="footerlocationinD">
            <div class=" pull-left" style="width: 52px;"><img src="<?php echo $this->config->item('base_url');?>assets/front/images/ft-delete.png" alt=""></div>
            <div class="footerlocationin">Online <br/>
              Cancellations</div>
          </div>
        </div>
      </div>
    </div>
  </div>
  
  <!--3-->
  <div class="container">
    <div class="row">
      <div class="col-lg-4 col-md-4 col-sm-4 footercopy">
        <div class="row"><a href="#">Privacy Statement</a> | <a href="#">Terms &amp; Conditions</a> | <a href="#">Privacy Policy </a></div>
      </div>
      <div class="col-lg-2 col-md-2 col-sm-2 footercopytext">
        <div class="row">&copy; Telefone Deal 2015 </div>
      </div>
      <div class="col-lg-6 col-md-6 col-sm-6 footercopysocial">
        <div class="row footercopysocialin">Connect with us <a href="#"><img src="<?php echo $this->config->item('base_url');?>assets/front/images/social-fb.png" alt=""></a> <a href="#"><img src="<?php echo $this->config->item('base_url');?>assets/front/images/social-tw.png" alt=""></a> <a href="#"><img src="<?php echo $this->config->item('base_url');?>assets/front/images/social-g+.png" alt=""></a></div>
      </div>
    </div>
    <!--row--> 
    
  </div>
  
  <!--4-->
  <div class="container">
    <div class="row">
      <div class="footerprd">
        <ul>
          <li class="width100"><strong>Mobiles:</strong></li>
          <li><a href="#">Moto E</a></li>
          <li><a href="#">Samsung Mobile</a></li>
          <li><a href="#">Micromax Mobile</a></li>
          <li><a href="#">Nokia Mobile</a></li>
          <li><a href="#">HTC Mobile</a></li>
          <li><a href="#">Sony Mobile</a></li>
          <li><a href="#">Apple Mobile</a></li>
          <li><a href="#">LG Mobile</a></li>
          <li><a href="#">Karbonn Mobile</a></li>
          <li><a href="#">View all</a></li>
        </ul>
        <ul>
          <li class="width100"><strong>Tablets:</strong></li>
          <li><a href="#">Moto E</a></li>
          <li><a href="#">Samsung Mobile</a></li>
          <li><a href="#">Micromax Mobile</a></li>
          <li><a href="#">Nokia Mobile</a></li>
          <li><a href="#">HTC Mobile</a></li>
          <li><a href="#">Sony Mobile</a></li>
          <li><a href="#">Apple Mobile</a></li>
          <li><a href="#">LG Mobile</a></li>
          <li><a href="#">Karbonn Mobile</a></li>
          <li><a href="#">View all</a></li>
        </ul>
        <ul>
          <li class="width100"><strong>Screen Guards:</strong></li>
          <li><a href="#">Moto E</a></li>
          <li><a href="#">Samsung Mobile</a></li>
          <li><a href="#">Micromax Mobile</a></li>
          <li><a href="#">Nokia Mobile</a></li>
          <li><a href="#">HTC Mobile</a></li>
          <li><a href="#">Sony Mobile</a></li>
          <li><a href="#">Apple Mobile</a></li>
          <li><a href="#">LG Mobile</a></li>
          <li><a href="#">Karbonn Mobile</a></li>
          <li><a href="#">View all</a></li>
        </ul>
        <ul>
          <li class="width100"><strong>Mobiles:</strong></li>
          <li><a href="#">Moto E</a></li>
          <li><a href="#">Samsung Mobile</a></li>
          <li><a href="#">Micromax Mobile</a></li>
          <li><a href="#">Nokia Mobile</a></li>
          <li><a href="#">HTC Mobile</a></li>
          <li><a href="#">Sony Mobile</a></li>
          <li><a href="#">Apple Mobile</a></li>
          <li><a href="#">LG Mobile</a></li>
          <li><a href="#">Karbonn Mobile</a></li>
          <li><a href="#">View all</a></li>
        </ul>
        <ul>
          <li class="width100"><strong>Tablets:</strong></li>
          <li><a href="#">Moto E</a></li>
          <li><a href="#">Samsung Mobile</a></li>
          <li><a href="#">Micromax Mobile</a></li>
          <li><a href="#">Nokia Mobile</a></li>
          <li><a href="#">HTC Mobile</a></li>
          <li><a href="#">Sony Mobile</a></li>
          <li><a href="#">Apple Mobile</a></li>
          <li><a href="#">LG Mobile</a></li>
          <li><a href="#">Karbonn Mobile</a></li>
          <li><a href="#">View all</a></li>
        </ul>
        <ul>
          <li class="width100"><strong>Screen Guards:</strong></li>
          <li><a href="#">Moto E</a></li>
          <li><a href="#">Samsung Mobile</a></li>
          <li><a href="#">Micromax Mobile</a></li>
          <li><a href="#">Nokia Mobile</a></li>
          <li><a href="#">HTC Mobile</a></li>
          <li><a href="#">Sony Mobile</a></li>
          <li><a href="#">Apple Mobile</a></li>
          <li><a href="#">LG Mobile</a></li>
          <li><a href="#">Karbonn Mobile</a></li>
          <li><a href="#">View all</a></li>
        </ul>
      </div>
    </div>
  </div>
  
  <!--5-->
  <div class="container">
    <div class="row">
      <div class="footerbottom">
        <div class="footerbottomtext">Payment Method</div>
        <div><img src="<?php echo $this->config->item('base_url');?>assets/front/images/c-visa.png" alt=""><img src="<?php echo $this->config->item('base_url');?>assets/front/images/c-mast.png" alt=""><img src="<?php echo $this->config->item('base_url');?>assets/front/images/c-msto.png" alt=""><img src="<?php echo $this->config->item('base_url');?>assets/front/images/c-amex.png" alt=""><img src="<?php echo $this->config->item('base_url');?>assets/front/images/c-rupa.png" alt=""></div>
      </div>
    </div>
  </div>
  <!--end--> 
  
</footer>
</div>
<script src="<?php echo $this->config->item('base_url');?>assets/front/js/telefonedeal.js"  type="text/javascript"></script>
<script src="<?php echo $this->config->item('base_url');?>assets/front/js/products.js"></script>
<script src="<?php echo $this->config->item('base_url');?>assets/front/js/cart.js"></script>
<script src="<?php echo $this->config->item('base_url');?>assets/front/js/checkout.js"></script>
<script src="<?php echo $this->config->item('base_url');?>assets/front/js/cbpHorizontalMenu.min.js"></script>
<script src="<?php echo $this->config->item('base_url');?>assets/front/js/users.js"></script>
<script src="<?php echo $this->config->item('base_url');?>assets/front/js/login.js"></script>
</body>
</html>
