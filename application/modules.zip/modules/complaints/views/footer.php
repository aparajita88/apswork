
		<!-- admin -->
        <script src="http://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.min.js"></script>

		<script src="<?php echo $this->config->item('base_url');?>assets/admin/jquery/jquery.js"></script>
		<!--<script src="//code.jquery.com/jquery-1.11.3.min.js"></script>-->		<script src="<?php echo $this->config->item('base_url');?>assets/admin/jquery-browser-mobile/jquery.browser.mobile.js"></script>
		<script src="<?php echo $this->config->item('base_url');?>assets/admin/bootstrap/js/bootstrap.js"></script>		<!--<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>-->		<script src="<?php echo $this->config->item('base_url');?>assets/admin/nanoscroller/nanoscroller.js"></script>		<script src="<?php echo $this->config->item('base_url');?>assets/admin/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>		<script src="<?php echo $this->config->item('base_url');?>assets/admin/magnific-popup/magnific-popup.js"></script>		<script src="<?php echo $this->config->item('base_url');?>assets/admin/jquery-placeholder/jquery.placeholder.js"></script>
		
		<!-- Specific Page admin -->		<script src="<?php echo $this->config->item('base_url');?>assets/admin/jquery-ui/js/jquery-ui-1.10.4.custom.js"></script>		<script src="<?php echo $this->config->item('base_url');?>assets/admin/jquery-ui-touch-punch/jquery.ui.touch-punch.js"></script>		<script src="<?php echo $this->config->item('base_url');?>assets/admin/jquery-appear/jquery.appear.js"></script>		<script src="<?php echo $this->config->item('base_url');?>assets/admin/bootstrap-multiselect/bootstrap-multiselect.js"></script>		<script src="<?php echo $this->config->item('base_url');?>assets/admin/jquery-easypiechart/jquery.easypiechart.js"></script>		<script src="<?php echo $this->config->item('base_url');?>assets/admin/flot/jquery.flot.js"></script>		<script src="<?php echo $this->config->item('base_url');?>assets/admin/flot-tooltip/jquery.flot.tooltip.js"></script>		<script src="<?php echo $this->config->item('base_url');?>assets/admin/flot/jquery.flot.pie.js"></script>		<script src="<?php echo $this->config->item('base_url');?>assets/admin/flot/jquery.flot.categories.js"></script>		<script src="<?php echo $this->config->item('base_url');?>assets/admin/flot/jquery.flot.resize.js"></script>		<script src="<?php echo $this->config->item('base_url');?>assets/admin/jquery-sparkline/jquery.sparkline.js"></script>		<script src="<?php echo $this->config->item('base_url');?>assets/admin/raphael/raphael.js"></script>		<script src="<?php echo $this->config->item('base_url');?>assets/admin/morris/morris.js"></script>		<script src="<?php echo $this->config->item('base_url');?>assets/admin/gauge/gauge.js"></script>		<script src="<?php echo $this->config->item('base_url');?>assets/admin/snap-svg/snap.svg.js"></script>		<script src="<?php echo $this->config->item('base_url');?>assets/admin/liquid-meter/liquid.meter.js"></script>		<script src="<?php echo $this->config->item('base_url');?>assets/admin/jqvmap/jquery.vmap.js"></script>		<script src="<?php echo $this->config->item('base_url');?>assets/admin/jqvmap/data/jquery.vmap.sampledata.js"></script>		<script src="<?php echo $this->config->item('base_url');?>assets/admin/jqvmap/maps/jquery.vmap.world.js"></script>		<script src="<?php echo $this->config->item('base_url');?>assets/admin/jqvmap/maps/continents/jquery.vmap.africa.js"></script>		<script src="<?php echo $this->config->item('base_url');?>assets/admin/jqvmap/maps/continents/jquery.vmap.asia.js"></script>		<script src="<?php echo $this->config->item('base_url');?>assets/admin/jqvmap/maps/continents/jquery.vmap.australia.js"></script>		<script src="<?php echo $this->config->item('base_url');?>assets/admin/jqvmap/maps/continents/jquery.vmap.europe.js"></script>		<script src="<?php echo $this->config->item('base_url');?>assets/admin/jqvmap/maps/continents/jquery.vmap.north-america.js"></script>		<script src="<?php echo $this->config->item('base_url');?>assets/admin/jqvmap/maps/continents/jquery.vmap.south-america.js"></script>
		
		
		<script src="<?php echo $this->config->item('base_url');?>assets/admin/fuelux/js/spinner.js"></script>		<script src="<?php echo $this->config->item('base_url');?>assets/admin/dropzone/dropzone.js"></script>		<script src="<?php echo $this->config->item('base_url');?>assets/admin/bootstrap-markdown/js/markdown.js"></script>		<script src="<?php echo $this->config->item('base_url');?>assets/admin/bootstrap-markdown/js/to-markdown.js"></script>		<script src="<?php echo $this->config->item('base_url');?>assets/admin/bootstrap-markdown/js/bootstrap-markdown.js"></script>		<script src="<?php echo $this->config->item('base_url');?>assets/admin/codemirror/lib/codemirror.js"></script>		<script src="<?php echo $this->config->item('base_url');?>assets/admin/codemirror/addon/selection/active-line.js"></script>		<script src="<?php echo $this->config->item('base_url');?>assets/admin/codemirror/addon/edit/matchbrackets.js"></script>		<script src="<?php echo $this->config->item('base_url');?>assets/admin/codemirror/mode/javascript/javascript.js"></script>		<script src="<?php echo $this->config->item('base_url');?>assets/admin/codemirror/mode/xml/xml.js"></script>		<script src="<?php echo $this->config->item('base_url');?>assets/admin/codemirror/mode/htmlmixed/htmlmixed.js"></script>		<script src="<?php echo $this->config->item('base_url');?>assets/admin/codemirror/mode/css/css.js"></script>		<script src="<?php echo $this->config->item('base_url');?>assets/admin/summernote/summernote.js"></script>		<script src="<?php echo $this->config->item('base_url');?>assets/admin/bootstrap-maxlength/bootstrap-maxlength.js"></script>		<script src="<?php echo $this->config->item('base_url');?>assets/admin/ios7-switch/ios7-switch.js"></script>		<script src="<?php echo $this->config->item('base_url');?>assets/admin/bootstrap-confirmation/bootstrap-confirmation.js"></script>		
		
		
		<!-- Specific Page admin -->		<script src="<?php echo $this->config->item('base_url');?>assets/admin/select2/select2.js"></script>		<script src="<?php echo $this->config->item('base_url');?>assets/admin/jquery-datatables/media/js/jquery.dataTables.js"></script>		<script src="<?php echo $this->config->item('base_url');?>assets/admin/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js"></script>		<script src="<?php echo $this->config->item('base_url');?>assets/admin/jquery-datatables-bs3/assets/js/datatables.js"></script>		
		
		
		<!-- Theme Base, Components and Settings -->
		<script src="<?php echo $this->config->item('base_url');?>assets/admin/javascripts/theme.js"></script>
		
		<!-- Theme Custom -->
		<script src="<?php echo $this->config->item('base_url');?>assets/admin/javascripts/theme.custom.js"></script>
		
		<!-- Theme Initialization Files -->

		<script src="<?php echo $this->config->item('base_url');?>assets/admin/javascripts/theme.init.js"></script>


		<!-- Specific Page admin -->		<script src="<?php echo $this->config->item('base_url');?>assets/admin/admin/isotope/jquery.isotope.js"></script>
		<script src="<?php echo $this->config->item('base_url');?>assets/admin/javascripts/pages/examples.mediagallery.js"></script>

		<!-- Examples -->
		<script src="<?php echo $this->config->item('base_url');?>assets/admin/javascripts/tables/examples.datatables.default.js"></script>
		<script src="<?php echo $this->config->item('base_url');?>assets/admin/javascripts/tables/examples.datatables.row.with.details.js"></script>
		<script src="<?php echo $this->config->item('base_url');?>assets/admin/javascripts/tables/examples.datatables.tabletools.js"></script>
		
		<!-- Examples -->
		<script src="<?php echo $this->config->item('base_url');?>assets/admin/javascripts/forms/examples.advanced.form.js"></script>

		<!-- Module Js's -->
		<script src="<?php echo $this->config->item('base_url');?>assets/admin/js/user.js"></script>
        <script src="<?php echo $this->config->item('base_url');?>assets/admin/js/vendortype.js"></script>
        <script src="<?php echo $this->config->item('base_url');?>assets/admin/js/vendorservice.js"></script>
        <script src="<?php echo $this->config->item('base_url');?>assets/admin/js/vendor.js"></script>
		<script src="<?php echo $this->config->item('base_url');?>assets/admin/js/category.js"></script>
		<script src="<?php echo $this->config->item('base_url');?>assets/admin/js/cms.js"></script>		
		<script src="<?php echo $this->config->item('base_url');?>assets/admin/js/attributes.js"></script>
		<script src="<?php echo $this->config->item('base_url');?>assets/admin/js/products.js"></script>
		<script src="<?php echo $this->config->item('base_url');?>assets/admin/js/brands.js"></script>
		<script src="<?php echo $this->config->item('base_url');?>assets/admin/js/banners.js"></script>
		<script src="<?php echo $this->config->item('base_url');?>assets/admin/js/merchantUser.js"></script>
		<script src="<?php echo $this->config->item('base_url');?>assets/admin/js/sitesetting.js"></script>
		<script src="<?php echo $this->config->item('base_url');?>assets/admin/js/email.js"></script>
		<script src="<?php echo $this->config->item('base_url');?>assets/admin/js/newsletters.js"></script>
		<script src="<?php echo $this->config->item('base_url');?>assets/admin/js/coupons.js"></script>
		<script src="<?php echo $this->config->item('base_url');?>assets/admin/js/country.js"></script>
		<script src="<?php echo $this->config->item('base_url');?>assets/admin/js/state.js"></script>
		<script src="<?php echo $this->config->item('base_url');?>assets/admin/js/zip.js"></script>
		<script src="<?php echo $this->config->item('base_url');?>assets/admin/js/admin.js"></script>
		<script src="<?php echo $this->config->item('base_url');?>assets/admin/js/validation.js"></script>
		<script src="<?php echo $this->config->item('base_url');?>assets/admin/moment/moment.js"></script>
		<script src="<?php echo $this->config->item('base_url');?>assets/admin/fullcalendar/fullcalendar.js"></script>
		<script src="<?php echo $this->config->item('base_url');?>assets/admin/jquery-validation/jquery.validate.js"></script>
        <script type="text/javascript">
            $(function () {
				$( ".datepicker" ).datepicker();
            });
        </script>
        
		<!-- Examples -->
	<!--	<script src="<?php echo $this->config->item('base_url');?>assets/admin/javascripts/dashboard/examples.dashboard.js"></script>!-->
	<script src="<?php echo $this->config->item('base_url');?>assets/admin/fullcalendar/examples.calendar.js"></script>
	<script src="<?php echo $this->config->item('base_url');?>assets/admin1/javascripts/forms/examples.advanced.form.js"></script>

	
	</body>
</html>
