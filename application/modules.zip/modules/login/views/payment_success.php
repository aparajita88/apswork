<?php  require_once(FCPATH.'assets/front/lib/header_bk.php'); ?> 
<!-- Login Section -->
<section class="login_section">
	<div class="container">
    	
      
        <div class="card card-container for_sign_up_card">
          
             
            
         
           <div class="heading_div" style="padding:100px 0 200px 0;">
            	<h4 class="text-center" style="color:#52bdf3; font-size: 40px;">Thank you!</h4> </br>
            	<p class="text-center" style="font-size: 18px;">We have received your payment, Mr/Mrs (<?= $fullname;?>). <br>Smartworks would be reaching out to you soon!</b></p>
          		<div class="clearfix"></div>
            </div>
            
         
				
				
				
				
          
        </div> 
        
         
        
    </div>
</section>   


<?php require_once(FCPATH.'assets/front/lib/footer.php'); ?> 

