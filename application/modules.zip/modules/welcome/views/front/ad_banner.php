<div class="adv-banner" >
  <div class="container">
    <div class="row">
    	
        <div class="col-lg-12 col-md-12 col-sm-12 adv-bannerin">
        <div class="bannerbtn"><button type="button" class="btn btn-default"> SHOP NOW </button></div>
        <img src="<?php echo $this->config->item('base_url');?>assets/front/images/banner-adv.png" alt="">
        </div>
        
    </div>
  </div>
</div>