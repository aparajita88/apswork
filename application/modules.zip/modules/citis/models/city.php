<?php
class city extends MY_Model {
	
	public function __construct() {
	   	parent::__construct();
	   	 $this->load->database();
    }
        
	
}
?>
