<?php require_once(FCPATH.'assets/admin/lib/header2.php'); ?> 
<section role="main" class="content-body">
<div class="row">			
<!-- start: page -->
<section class="panel">
<div class="panel-body"><h2 class="panel-title">Payment Status</h2></div>
<div class="panel-body panel_body_top">
	<div class="row booking_carousel_min_min">	
	<div class="card card-container for_sign_up_card">
       <div class="heading_div" style="padding:100px 0 200px 0;">
        	<h4 class="text-center" style="color:#52bdf3; font-size: 40px;">Sorry!</h4> </br>
        	<p class="text-center" style="font-size: 18px;">There are some errors in payment..<br>Please try again later.</b></p>
      		<div class="clearfix"></div>
        </div>
    </div> 	
</div>
</div>
</section>
<div class="clearfix"></div>
<?php require_once(FCPATH.'assets/admin/lib/right.php'); ?> 
</section>
<?php require_once(FCPATH.'assets/admin/lib/footer3.php'); ?>

