<div class="col-lg-2 col-md-2 col-sm-2 padd0"> 
        
        <!--1-->
        <div class="sbox">
          <div class="text-center">Chevron Flip Cover with Chevron HD Screen Guard ... & 3.5mm Stereo Earphones</div>
          <div>
            <div class="pull-left"><img src="<?php echo $this->config->item('base_url');?>assets/front/images/products/prd1.jpg" alt=""></div>
            <div class="pull-right ">
              <h4><i class="fa fa-inr"></i> 499</h4>
              <a role="button" class="btn btn-primary" href="#">Shop Now</a> </div>
          </div>
        </div>
        <!--2-->
        <div class="sboximg">
          <div class="text-center">Amaze Fashion Charging/Data Cable</div>
          <div>
            <div class="pull-left"><img src="<?php echo $this->config->item('base_url');?>assets/front/images/products/prd2.jpg" alt=""></div>
            <div class="pull-right marTop4"><a role="button" class="btn btn-primary" href="#">Shop Now</a></div>
          </div>
        </div>
        <!--1-->
        <div class="sbox">
          <div class="text-center">Chevron Flip Cover with Chevron HD Screen Guard ... & 3.5mm Stereo Earphones</div>
          <div>
            <div class="pull-left"><img src="<?php echo $this->config->item('base_url');?>assets/front/images/products/prd1.jpg" alt=""></div>
            <div class="pull-right ">
              <h4><i class="fa fa-inr"></i> 499</h4>
              <a role="button" class="btn btn-primary" href="#">Shop Now</a> </div>
          </div>
        </div>
        <!--2-->
        <div class="sboximg">
          <div class="text-center">Amaze Fashion Charging/Data Cable</div>
          <div>
            <div class="pull-left"><img src="<?php echo $this->config->item('base_url');?>assets/front/images/products/prd2.jpg" alt=""></div>
            <div class="pull-right marTop4"><a role="button" class="btn btn-primary" href="#">Shop Now</a></div>
          </div>
        </div>
        <!--1-->
        <div class="sbox">
          <div class="text-center">Chevron Flip Cover with Chevron HD Screen Guard ... & 3.5mm Stereo Earphones</div>
          <div>
            <div class="pull-left"><img src="<?php echo $this->config->item('base_url');?>assets/front/images/products/prd1.jpg" alt=""></div>
            <div class="pull-right ">
              <h4><i class="fa fa-inr"></i> 499</h4>
              <a role="button" class="btn btn-primary" href="#">Shop Now</a> </div>
          </div>
        </div>
        <!--2-->
        <div class="sboximg">
          <div class="text-center">Amaze Fashion Charging/Data Cable</div>
          <div>
            <div class="pull-left"><img src="<?php echo $this->config->item('base_url');?>assets/front/images/products/prd2.jpg" alt=""></div>
            <div class="pull-right marTop4"><a role="button" class="btn btn-primary" href="#">Shop Now</a></div>
          </div>
        </div>
        <!--1-->
        <div class="sbox">
          <div class="text-center">Chevron Flip Cover with Chevron HD Screen Guard ... & 3.5mm Stereo Earphones</div>
          <div>
            <div class="pull-left"><img src="<?php echo $this->config->item('base_url');?>assets/front/images/products/prd1.jpg" alt=""></div>
            <div class="pull-right ">
              <h4><i class="fa fa-inr"></i> 499</h4>
              <a role="button" class="btn btn-primary" href="#">Shop Now</a> </div>
          </div>
        </div>
        <!--2-->
        <div class="sboximg">
          <div class="text-center">Amaze Fashion Charging/Data Cable</div>
          <div>
            <div class="pull-left"><img src="<?php echo $this->config->item('base_url');?>assets/front/images/products/prd2.jpg" alt=""></div>
            <div class="pull-right marTop4"><a role="button" class="btn btn-primary" href="#">Shop Now</a></div>
          </div>
        </div>
        <!--1-->
        <div class="sbox">
          <div class="text-center">Chevron Flip Cover with Chevron HD Screen Guard ... & 3.5mm Stereo Earphones</div>
          <div>
            <div class="pull-left"><img src="<?php echo $this->config->item('base_url');?>assets/front/images/products/prd1.jpg" alt=""></div>
            <div class="pull-right ">
              <h4><i class="fa fa-inr"></i> 499</h4>
              <a role="button" class="btn btn-primary" href="#">Shop Now</a> </div>
          </div>
        </div>
        <!--2-->
        <div class="sboximg">
          <div class="text-center">Amaze Fashion Charging/Data Cable</div>
          <div>
            <div class="pull-left"><img src="<?php echo $this->config->item('base_url');?>assets/front/images/products/prd2.jpg" alt=""></div>
            <div class="pull-right marTop4"><a role="button" class="btn btn-primary" href="#">Shop Now</a></div>
          </div>
        </div>
         <!--1-->
        <div class="sbox">
          <div class="text-center">Chevron Flip Cover with Chevron HD Screen Guard ... & 3.5mm Stereo Earphones</div>
          <div>
            <div class="pull-left"><img src="<?php echo $this->config->item('base_url');?>assets/front/images/products/prd1.jpg" alt=""></div>
            <div class="pull-right ">
              <h4><i class="fa fa-inr"></i> 499</h4>
              <a role="button" class="btn btn-primary" href="#">Shop Now</a> </div>
          </div>
        </div>
        <!--2-->
        <div class="sboximg">
          <div class="text-center">Amaze Fashion Charging/Data Cable</div>
          <div>
            <div class="pull-left"><img src="<?php echo $this->config->item('base_url');?>assets/front/images/products/prd2.jpg" alt=""></div>
            <div class="pull-right marTop4"><a role="button" class="btn btn-primary" href="#">Shop Now</a></div>
          </div>
        </div>
        <!--1-->
        <div class="sbox">
          <div class="text-center">Chevron Flip Cover with Chevron HD Screen Guard ... & 3.5mm Stereo Earphones</div>
          <div>
            <div class="pull-left"><img src="<?php echo $this->config->item('base_url');?>assets/front/images/products/prd1.jpg" alt=""></div>
            <div class="pull-right ">
              <h4><i class="fa fa-inr"></i> 499</h4>
              <a role="button" class="btn btn-primary" href="#">Shop Now</a> </div>
          </div>
        </div>
        <!--2-->
        <div class="sboximg">
          <div class="text-center">Amaze Fashion Charging/Data Cable</div>
          <div>
            <div class="pull-left"><img src="<?php echo $this->config->item('base_url');?>assets/front/images/products/prd2.jpg" alt=""></div>
            <div class="pull-right marTop4"><a role="button" class="btn btn-primary" href="#">Shop Now</a></div>
          </div>
        </div>
        <!--1-->
        <div class="sbox">
          <div class="text-center">Chevron Flip Cover with Chevron HD Screen Guard ... & 3.5mm Stereo Earphones</div>
          <div>
            <div class="pull-left"><img src="<?php echo $this->config->item('base_url');?>assets/front/images/products/prd1.jpg" alt=""></div>
            <div class="pull-right ">
              <h4><i class="fa fa-inr"></i> 499</h4>
              <a role="button" class="btn btn-primary" href="#">Shop Now</a> </div>
          </div>
        </div>
        <!--2-->
        <div class="sboximg">
          <div class="text-center">Amaze Fashion Charging/Data Cable</div>
          <div>
            <div class="pull-left"><img src="<?php echo $this->config->item('base_url');?>assets/front/images/products/prd2.jpg" alt=""></div>
            <div class="pull-right marTop4"><a role="button" class="btn btn-primary" href="#">Shop Now</a></div>
          </div>
        </div>
        <!--1-->
        
        
        <!--n--> 
        
      </div>
