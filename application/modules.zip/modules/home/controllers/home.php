<?php
class home extends MY_Controller {
	var $gallery_path;
	var $gallery_path_url;
	var $doc_path;
	public function __construct() {
		parent::__construct();
		$this->load->model('home_model');
		$this->load->model('location/location_model', 'lm');
		$this->load->model('rooms/rooms_model');
		$this->load->model('cms/cms_model');
		$this->load->helper('form','url'); 
		$this->gallery_path = realpath(APPPATH . '../assets/uploads');
		$this->gallery_path_url = $this->config->item('base_url').'assets/uploads/';
		$this->doc_path=realpath(APPPATH . '../assets/uploads/doc');
	}
	/*This action call for plans and pricing*/
    public function price(){
	    $data['title'] = "SMARTWORKS-HOME"; 
		$this->session->unset_userdata('newdata');
		$data['location_arr']=$this->lm->getcities();
		$this->load->view('price',$data);	
    }
    /*This action call for home/index page*/
	public function index(){
		$data['location'] = $this->uri->segment(3);
		$data['data'] = $this->lm->getLocationData("Kolkata");
		$data['location_arr']=$this->lm->getcities();

		$data['meta_key'] = 'Business Co-working space, Business Dynamics, highest Productivity, Modern business dynamics, state of the art facilities, Growth aggregator,business engagement, Social, bounce ideas, events and seminars, high end interactions,plug and play options, deployed in your business, support staff, high quality, conference venues, business hours, connected, effective IT services, ecosystem, nurturing startups,
		dynamics, conducting business, collaborative development, business location, expansion, reduced time, exchange information, meeting rooms, flexible space, business entity, business support, collaborative social platforms,
		control for costs, control for time, optimizing your costs, expansion, business peripherals, expand, go lean, massive groups, ease of business, learning and development, conference rooms , telecommunication facilities, business lounge business support, energize your teams,
		one person task force, proper facilities, low cost, flexibility in lease, integrations for expansion, low cost workspace, flexible, business support, Virtual offices, shared office, professional network, opportunity, new business,
		Agility, turnkey solutions, project head, temporary office solutions, office solution, local business, flexible spaces, collaboration areas, culture centric focus, engaging, business support, service options, connected, business services, project opportunities';

		$var='ABOUT SMART';
		$data['cms_content_about']= $this->cms_model->cms_content_about($var);
		
		$data['cms_content_services']= $this->cms_model->get_cms_content_home('home','1');
		$data['cms_content_smart_services']= $this->cms_model->get_cms_content_home('home','2');
		$data['cms_content_i_am_a']= $this->cms_model->get_cms_content_home('home','0');
		$data['subscription']=$this->home_model->get_subscription();
		
		$data['title'] = "SMARTWORKS-HOME"; 
		$this->session->unset_userdata('newdata');
		$this->load->view('index',$data);
	}
	/*This action call for CMS page(s)*/
	public function page($slg){
		$data = array();
		$data['cms_page_content']= $this->cms_model->get_cms_page_content($slg);
		if(empty($data['cms_page_content'])){
			exit('No Page found!');
		}
		$data['location_arr']=$this->lm->getcities();
		$data['title'] = "SMARTWORKS-".$data['cms_page_content']['title']; 
		$data['meta_key'] = $data['cms_page_content']['meta_keywords'];
		$this->load->view('cms_page',$data);
	}
}
?>
