<div class="modal-dialog">
	
                        <div class="modal-content">
							<form id="frmapproval" methos="post">
								<input type="hidden" name="appid" id="appid" value="<?php if($template){echo $template[0]['emailId'];}?>"/>
								
								 <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                <h4 class="modal-title"> <?php echo $template[0]['title'] ?></h4>
                            </div>
                            <div class="modal-body">
                            
                               
                           
                             <?php echo $template[0]['description'] ?>
                   
                            </div>
                           
							</form>
                           
                        </div>
                    </div>
                   
<!---<div style="width:100%; margin:0 auto; border:10px solid #0F70A8;">
<div style="width:100%; margin:0 auto; border-bottom:1px solid #CCC;">
<div style="float:left; padding:20px; border:1px solid #ccc; width:30%; text-align:center; margin:30px;"><img src="http://smartworks.demostage.net/assets/front/images/logobk.png" /></div>

<div style="float:right; padding:20px; width:15%;">&nbsp;</div>

<div style="font:0; line-height:0; clear:both;">&nbsp;</div>
</div>

<div style="width:93%; margin:0 auto; padding:10px 20px;">
<h1>Hi receiverPHL,</h1>

<p>Please login with the newly system genarated Password.</p>

<p>Password : passPHL</p>

<p>If you have any issues we will be happy to help you. You can contact us on <a href="mailto:info@sworks.co.in" style=" text-decoration:none; color:#0F70A8">info@sworks.co.in</a></p>
&nbsp;

<p>Sincerely,<br />
Smartworks Business Center.</p>

<div style="font:0; line-height:0; clear:both;">&nbsp;</div>
</div>

<div style="font:0; line-height:0; clear:both;">&nbsp;</div>
</div>-->